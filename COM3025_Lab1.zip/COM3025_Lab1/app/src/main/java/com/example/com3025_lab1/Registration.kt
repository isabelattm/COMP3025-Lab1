package com.example.com3025_lab1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import android.view.View

class Registration : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var successMessageTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        auth = FirebaseAuth.getInstance()
        successMessageTextView = findViewById(R.id.successMessage)
        database = FirebaseDatabase.getInstance("https://lab01-registration-default-rtdb.firebaseio.com/")

        val registrationButton = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.RegistrationBttn)

        registrationButton.setOnClickListener {
            val studentId = findViewById<EditText>(R.id.ID).text.toString()
            val name = findViewById<EditText>(R.id.Name).text.toString()
            val age = findViewById<EditText>(R.id.Age).text.toString()
            val address = findViewById<EditText>(R.id.Address).text.toString()
            val email = findViewById<EditText>(R.id.Email).text.toString()

            if (studentId.isNotEmpty() && name.isNotEmpty() && age.isNotEmpty() && address.isNotEmpty() && email.isNotEmpty()) {

                saveUserData(studentId, name, age, address, email)
                
            } else {

            }
        }
    }

    private fun saveUserData(studentId: String, name: String, age: String, address: String, email: String) {
        val userData = mapOf(
            "name" to name,
            "age" to age,
            "address" to address,
            "email" to email
        )

        val usersRef = database.reference.child("Lab01-Registration").child("users").child(studentId)
        usersRef.setValue(userData)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // Data saved successfully
                    successMessageTextView.text = "Student Account created successfully"
                    successMessageTextView.visibility = View.VISIBLE
                    finish()

                } else {

                    val exception = task.exception

                }
            }
    }
}